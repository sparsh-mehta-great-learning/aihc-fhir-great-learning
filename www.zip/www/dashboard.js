/**
 * EpicCare Dashboard - EPIC EHR-style interface
 * Connects to HAPI FHIR R4 server
 * n8n AI features: Discharge Summary, Pre-visit Summary
 */

const FHIR_BASE = `http://${window.location.hostname || 'localhost'}:4004/hapi-fhir-jpaserver/fhir`;

let selectedPatient = null;
const patientCache = new Map();

const elements = {
  currentDate: document.getElementById('currentDate'),
  patientSearch: document.getElementById('patientSearch'),
  searchBtn: document.getElementById('searchBtn'),
  addPatientBtn: document.getElementById('addPatientBtn'),
  patientList: document.getElementById('patientList'),
  patientListSection: document.getElementById('patientListSection'),
  patientChartSection: document.getElementById('patientChartSection'),
  patientBanner: document.getElementById('patientBanner'),
  bannerMRN: document.getElementById('bannerMRN'),
  bannerName: document.getElementById('bannerName'),
  bannerDOB: document.getElementById('bannerDOB'),
  bannerAge: document.getElementById('bannerAge'),
  bannerSex: document.getElementById('bannerSex'),
  bannerPhone: document.getElementById('bannerPhone'),
  editPatientBtn: document.getElementById('editPatientBtn'),
  deletePatientBtn: document.getElementById('deletePatientBtn'),
  clearPatientBtn: document.getElementById('clearPatientBtn'),
  patientModal: document.getElementById('patientModal'),
  patientModalTitle: document.getElementById('patientModalTitle'),
  patientForm: document.getElementById('patientForm'),
  closePatientModal: document.getElementById('closePatientModal'),
  cancelPatientModal: document.getElementById('cancelPatientModal'),
  savePatientBtn: document.getElementById('savePatientBtn'),
  loadingOverlay: document.getElementById('loadingOverlay'),
  generateDischargeBtn: document.getElementById('generateDischargeBtn'),
  generatePrevisitBtn: document.getElementById('generatePrevisitBtn'),
  dischargeContent: document.getElementById('dischargeContent'),
  previsitContent: document.getElementById('previsitContent'),
};

document.addEventListener('DOMContentLoaded', () => {
  setCurrentDate();
  bindEvents();
  loadInitialPatients();
});

function setCurrentDate() {
  const now = new Date();
  if (elements.currentDate) {
    elements.currentDate.textContent = now.toLocaleDateString('en-US', {
      weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
    });
  }
}

function bindEvents() {
  elements.searchBtn?.addEventListener('click', handleSearch);
  elements.patientSearch?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleSearch();
  });
  elements.clearPatientBtn?.addEventListener('click', clearPatient);
  elements.addPatientBtn?.addEventListener('click', openAddPatientModal);
  elements.editPatientBtn?.addEventListener('click', openEditPatientModal);
  elements.deletePatientBtn?.addEventListener('click', deletePatient);
  elements.closePatientModal?.addEventListener('click', closePatientModal);
  elements.cancelPatientModal?.addEventListener('click', closePatientModal);
  elements.savePatientBtn?.addEventListener('click', savePatient);
  elements.patientModal?.querySelector('.epic-modal-overlay')?.addEventListener('click', closePatientModal);
  elements.generateDischargeBtn?.addEventListener('click', () => generateAISummary('discharge'));
  elements.generatePrevisitBtn?.addEventListener('click', () => generateAISummary('previsit'));

  document.querySelectorAll('.activity-item[data-tab]').forEach((item) => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      switchTab(item.dataset.tab);
    });
  });
}

async function loadInitialPatients() {
  await fetchAndRenderPatients('');
}

async function handleSearch() {
  const query = elements.patientSearch?.value?.trim() ?? '';
  await fetchAndRenderPatients(query);
}

async function fetchAndRenderPatients(query) {
  if (!elements.patientList) return;

  showLoading(true);
  try {
    const url = query
      ? `${FHIR_BASE}/Patient?_count=20&name=${encodeURIComponent(query)}`
      : `${FHIR_BASE}/Patient?_count=20`;
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const bundle = await response.json();
    const patients = bundle.entry?.map((e) => e.resource) ?? [];
    renderPatientList(patients);

    if (patients.length === 0) {
      elements.patientList.innerHTML = '<div class="empty-message">No patients found. Ensure FHIR server is running and has data (e.g. use r4-full image for sample patients).</div>';
    }
  } catch (err) {
    console.error('Search failed:', err);
    elements.patientList.innerHTML = `<div class="error-msg">Unable to fetch patients. Ensure the FHIR server is running at ${FHIR_BASE}. Error: ${err.message}</div>`;
  } finally {
    showLoading(false);
  }
}

function renderPatientList(patients) {
  if (!elements.patientList) return;
  patientCache.clear();
  patients.forEach((p) => patientCache.set(p.id, p));

  elements.patientList.innerHTML = patients
    .map((p) => {
      const name = formatPatientName(p);
      const birthDate = p.birthDate || '—';
      const gender = p.gender || '—';
      return `
        <div class="epic-patient-item" data-id="${p.id}">
          <div>
            <div class="patient-item-name">${escapeHtml(name)}</div>
            <div class="patient-item-meta">DOB: ${birthDate} | ${gender}</div>
          </div>
          <span class="patient-item-mrn">MRN: ${p.id}</span>
        </div>
      `;
    })
    .join('');

  elements.patientList.querySelectorAll('.epic-patient-item').forEach((el) => {
    el.addEventListener('click', () => {
      const patient = patientCache.get(el.dataset.id);
      if (patient) selectPatient(patient);
    });
  });
}

function formatPatientName(p) {
  const human = p.name?.find((n) => n.use === 'official') || p.name?.[0];
  if (!human) return 'Unknown';
  const parts = [human.family, ...(human.given || [])].filter(Boolean);
  return parts.join(', ');
}

function getPatientAge(birthDate) {
  if (!birthDate) return '—';
  const today = new Date();
  const dob = new Date(birthDate);
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;
  return age;
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function selectPatient(patient) {
  selectedPatient = patient;
  document.querySelector('.epic-layout')?.classList.add('has-patient');

  elements.patientListSection?.classList.add('hidden');
  elements.patientChartSection?.classList.remove('hidden');
  elements.patientBanner?.classList.remove('hidden');

  updatePatientBanner(patient);
  elements.generateDischargeBtn.disabled = false;
  elements.generatePrevisitBtn.disabled = false;

  loadAllergies();
  loadOverview();
  loadMedications();
  loadLabs();
  loadProblems();
  loadVitals();
  loadDemographics();

  switchTab('allergies');
}

function updatePatientBanner(p) {
  const name = formatPatientName(p);
  const phone = p.telecom?.find((t) => t.system === 'phone')?.value || '—';
  elements.bannerMRN.textContent = p.id;
  elements.bannerName.textContent = name;
  elements.bannerDOB.textContent = p.birthDate || '—';
  elements.bannerAge.textContent = getPatientAge(p.birthDate);
  elements.bannerSex.textContent = p.gender || '—';
  elements.bannerPhone.textContent = phone;
}

function clearPatient() {
  selectedPatient = null;
  document.querySelector('.epic-layout')?.classList.remove('has-patient');

  elements.patientChartSection?.classList.add('hidden');
  elements.patientListSection?.classList.remove('hidden');
  elements.patientBanner?.classList.add('hidden');
  elements.patientSearch.value = '';
  elements.generateDischargeBtn.disabled = true;
  elements.generatePrevisitBtn.disabled = true;
  elements.dischargeContent.textContent = '';
  elements.previsitContent.textContent = '';
}

function switchTab(tabId) {
  document.querySelectorAll('.activity-item').forEach((i) => i.classList.remove('active'));
  document.querySelectorAll('.epic-tab-panel').forEach((p) => p.classList.remove('active'));

  const item = document.querySelector(`.activity-item[data-tab="${tabId}"]`);
  const panel = document.getElementById(`${tabId}Panel`);
  item?.classList.add('active');
  panel?.classList.add('active');
}

async function fhirGet(resource, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const res = await fetch(`${FHIR_BASE}/${resource}${qs ? '?' + qs : ''}`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function fhirPost(resource, body) {
  const res = await fetch(`${FHIR_BASE}/${resource}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/fhir+json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function fhirPut(resource, id, body) {
  const res = await fetch(`${FHIR_BASE}/${resource}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/fhir+json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function fhirDelete(resource, id) {
  const res = await fetch(`${FHIR_BASE}/${resource}/${id}`, { method: 'DELETE' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

function openAddPatientModal() {
  elements.patientModalTitle.textContent = 'Add Patient';
  document.getElementById('patientFormId').value = '';
  document.getElementById('patientFamily').value = '';
  document.getElementById('patientGiven').value = '';
  document.getElementById('patientBirthDate').value = '';
  document.getElementById('patientGender').value = '';
  document.getElementById('patientPhone').value = '';
  document.getElementById('patientAddress').value = '';
  elements.patientModal?.classList.remove('hidden');
}

function openEditPatientModal() {
  if (!selectedPatient) return;
  elements.patientModalTitle.textContent = 'Edit Patient';
  const p = selectedPatient;
  const name = p.name?.find((n) => n.use === 'official') || p.name?.[0];
  document.getElementById('patientFormId').value = p.id;
  document.getElementById('patientFamily').value = name?.family || '';
  document.getElementById('patientGiven').value = (name?.given || []).join(' ') || '';
  document.getElementById('patientBirthDate').value = p.birthDate || '';
  document.getElementById('patientGender').value = p.gender || '';
  document.getElementById('patientPhone').value = p.telecom?.find((t) => t.system === 'phone')?.value || '';
  const addr = p.address?.[0];
  const addrStr = addr ? [addr.line?.join(', '), addr.city, addr.state, addr.postalCode].filter(Boolean).join(', ') : '';
  document.getElementById('patientAddress').value = addrStr;
  elements.patientModal?.classList.remove('hidden');
}

function closePatientModal() {
  elements.patientModal?.classList.add('hidden');
}

function buildPatientResource() {
  const id = document.getElementById('patientFormId').value?.trim();
  const family = document.getElementById('patientFamily').value?.trim();
  const given = document.getElementById('patientGiven').value?.trim().split(/\s+/).filter(Boolean);
  const birthDate = document.getElementById('patientBirthDate').value || undefined;
  const gender = document.getElementById('patientGender').value || undefined;
  const phone = document.getElementById('patientPhone').value?.trim();
  const addressRaw = document.getElementById('patientAddress').value?.trim();

  const resource = {
    resourceType: 'Patient',
    name: [{ use: 'official', family: family || undefined, given: given.length ? given : undefined }].filter((n) => n.family || n.given),
  };
  if (birthDate) resource.birthDate = birthDate;
  if (gender) resource.gender = gender;
  if (phone) resource.telecom = [{ system: 'phone', value: phone }];
  if (addressRaw) {
    const parts = addressRaw.split(',').map((s) => s.trim());
    resource.address = [{
      line: parts[0] ? [parts[0]] : undefined,
      city: parts[1] || undefined,
      state: parts[2] || undefined,
      postalCode: parts[3] || undefined,
    }];
    resource.address[0] = Object.fromEntries(Object.entries(resource.address[0]).filter(([, v]) => v));
    if (Object.keys(resource.address[0]).length === 0) delete resource.address;
  }
  if (id) {
    resource.id = id;
  }
  return resource;
}

async function savePatient() {
  const family = document.getElementById('patientFamily').value?.trim();
  const given = document.getElementById('patientGiven').value?.trim();
  if (!family || !given) {
    alert('Family name and Given name are required.');
    return;
  }
  const resource = buildPatientResource();
  const isEdit = !!resource.id;
  showLoading(true);
  elements.savePatientBtn.disabled = true;
  try {
    if (isEdit) {
      await fhirPut('Patient', resource.id, resource);
    } else {
      await fhirPost('Patient', resource);
    }
    closePatientModal();
    const query = isEdit ? (elements.patientSearch?.value?.trim() ?? '') : '';
    if (!isEdit) elements.patientSearch.value = '';
    await fetchAndRenderPatients(query);
    if (isEdit && selectedPatient?.id === resource.id) {
      const updated = patientCache.get(resource.id) || resource;
      selectPatient(updated);
    }
  } catch (err) {
    alert(`Failed to save patient: ${err.message}`);
  } finally {
    showLoading(false);
    elements.savePatientBtn.disabled = false;
  }
}

async function deletePatient() {
  if (!selectedPatient) return;
  if (!confirm(`Delete patient ${formatPatientName(selectedPatient)} (MRN: ${selectedPatient.id})? This cannot be undone.`)) return;
  showLoading(true);
  try {
    await fhirDelete('Patient', selectedPatient.id);
    clearPatient();
    await fetchAndRenderPatients(elements.patientSearch?.value?.trim() ?? '');
  } catch (err) {
    alert(`Failed to delete patient: ${err.message}`);
  } finally {
    showLoading(false);
  }
}

async function loadAllergies() {
  const el = document.getElementById('allergiesContent');
  if (!el) return;
  el.innerHTML = '<p class="no-data">Loading allergies...</p>';
  if (!selectedPatient) return;

  try {
    const bundle = await fhirGet('AllergyIntolerance', { patient: selectedPatient.id, _count: 20 }).catch(() => ({ entry: [] }));
    const allergies = bundle.entry?.map((e) => e.resource) ?? [];

    el.innerHTML = allergies.length
      ? allergies
          .map(
            (a) => `
          <div class="allergy-item ${a.criticality === 'high' || a.criticality === 'low' ? 'severe' : ''}">
            <strong>${a.code?.text || a.code?.coding?.[0]?.display || 'Allergen'}</strong>
            <span> — ${a.type || '—'} | ${a.criticality || '—'} | ${a.clinicalStatus?.coding?.[0]?.code || '—'}</span>
          </div>
        `
          )
          .join('')
      : '<p class="no-data">No known allergies on record.</p>';
  } catch {
    el.innerHTML = '<p class="no-data">No known allergies on record.</p>';
  }
}

async function loadOverview() {
  const el = document.getElementById('overviewContent');
  if (!el) return;
  el.innerHTML = '<p class="no-data">Loading chart review...</p>';
  if (!selectedPatient) return;

  try {
    const [encBundle, condBundle] = await Promise.all([
      fhirGet('Encounter', { patient: selectedPatient.id, _count: 10 }).catch(() => ({ entry: [] })),
      fhirGet('Condition', { patient: selectedPatient.id, _count: 5 }).catch(() => ({ entry: [] })),
    ]);
    const encounters = encBundle.entry?.map((e) => e.resource) ?? [];
    const conditions = condBundle.entry?.map((e) => e.resource) ?? [];

    el.innerHTML = `
      <div class="epic-data-row header"><span>Recent Encounters</span><span>Status</span><span>Date</span></div>
      ${encounters.length ? encounters.map((e) => `<div class="epic-data-row"><span>${e.type?.[0]?.text || 'Encounter'}</span><span>${e.status || '—'}</span><span>${e.period?.start ? new Date(e.period.start).toLocaleDateString() : '—'}</span></div>`).join('') : '<div class="epic-data-row"><span class="no-data">No encounters</span></div>'}
      <h4 style="margin-top:20px">Active Problems</h4>
      ${conditions.length ? conditions.map((c) => `<div class="epic-data-row"><span>${c.code?.text || c.code?.coding?.[0]?.display || 'Condition'}</span><span>${c.clinicalStatus?.coding?.[0]?.code || '—'}</span><span>—</span></div>`).join('') : '<p class="no-data">No conditions found</p>'}
    `;
  } catch {
    el.innerHTML = '<p class="no-data">Unable to load chart review.</p>';
  }
}

async function loadMedications() {
  const el = document.getElementById('medicationsContent');
  if (!el) return;
  el.innerHTML = '<p class="no-data">Loading medications...</p>';
  if (!selectedPatient) return;

  try {
    const bundle = await fhirGet('MedicationRequest', { patient: selectedPatient.id, _count: 20 });
    const meds = bundle.entry?.map((e) => e.resource) ?? [];

    el.innerHTML = meds.length
      ? `<div class="epic-data-row header"><span>Medication</span><span>Status</span><span>Date</span></div>
         ${meds.map((m) => `<div class="epic-data-row"><span>${m.medicationCodeableConcept?.text || m.medicationCodeableConcept?.coding?.[0]?.display || '—'}</span><span>${m.status || '—'}</span><span>${m.authoredOn ? new Date(m.authoredOn).toLocaleDateString() : '—'}</span></div>`).join('')}`
      : '<p class="no-data">No medications found.</p>';
  } catch {
    el.innerHTML = '<p class="no-data">Unable to load medications.</p>';
  }
}

async function loadLabs() {
  const el = document.getElementById('labsContent');
  if (!el) return;
  el.innerHTML = '<p class="no-data">Loading lab results...</p>';
  if (!selectedPatient) return;

  try {
    const bundle = await fhirGet('Observation', { patient: selectedPatient.id, category: 'laboratory', _count: 20 });
    const obs = bundle.entry?.map((e) => e.resource) ?? [];

    el.innerHTML = obs.length
      ? `<div class="epic-data-row header"><span>Test</span><span>Value</span><span>Date</span></div>
         ${obs.map((o) => `<div class="epic-data-row"><span>${o.code?.text || o.code?.coding?.[0]?.display || 'Lab'}</span><span>${formatObsValue(o)}</span><span>${o.effectiveDateTime ? new Date(o.effectiveDateTime).toLocaleDateString() : '—'}</span></div>`).join('')}`
      : '<p class="no-data">No lab results found.</p>';
  } catch {
    el.innerHTML = '<p class="no-data">Unable to load lab results.</p>';
  }
}

function formatObsValue(o) {
  if (o.valueQuantity) return `${o.valueQuantity.value} ${o.valueQuantity.unit || ''}`.trim();
  if (o.valueString) return o.valueString;
  return o.valueCodeableConcept?.text || '—';
}

async function loadProblems() {
  const el = document.getElementById('problemsContent');
  if (!el) return;
  el.innerHTML = '<p class="no-data">Loading problem list...</p>';
  if (!selectedPatient) return;

  try {
    const bundle = await fhirGet('Condition', { patient: selectedPatient.id, _count: 20 });
    const conditions = bundle.entry?.map((e) => e.resource) ?? [];

    el.innerHTML = conditions.length
      ? `<div class="epic-data-row header"><span>Condition</span><span>Status</span><span>Date</span></div>
         ${conditions.map((c) => `<div class="epic-data-row"><span>${c.code?.text || c.code?.coding?.[0]?.display || 'Condition'}</span><span>${c.clinicalStatus?.coding?.[0]?.code || '—'}</span><span>${c.recordedDate ? new Date(c.recordedDate).toLocaleDateString() : '—'}</span></div>`).join('')}`
      : '<p class="no-data">No conditions found.</p>';
  } catch {
    el.innerHTML = '<p class="no-data">Unable to load problem list.</p>';
  }
}

async function loadVitals() {
  const el = document.getElementById('vitalsContent');
  if (!el) return;
  el.innerHTML = '<p class="no-data">Loading vitals...</p>';
  if (!selectedPatient) return;

  try {
    const bundle = await fhirGet('Observation', { patient: selectedPatient.id, category: 'vital-signs', _count: 20 });
    const vitals = bundle.entry?.map((e) => e.resource) ?? [];

    el.innerHTML = vitals.length
      ? `<div class="epic-data-row header"><span>Vital</span><span>Value</span><span>Date</span></div>
         ${vitals.map((v) => `<div class="epic-data-row"><span>${v.code?.text || v.code?.coding?.[0]?.display || 'Vital'}</span><span>${formatObsValue(v)}</span><span>${v.effectiveDateTime ? new Date(v.effectiveDateTime).toLocaleDateString() : '—'}</span></div>`).join('')}`
      : '<p class="no-data">No vital signs found.</p>';
  } catch {
    el.innerHTML = '<p class="no-data">Unable to load vitals.</p>';
  }
}

function loadDemographics() {
  const el = document.getElementById('demographicsContent');
  if (!el) return;
  if (!selectedPatient) return;

  const p = selectedPatient;
  const items = [
    { label: 'Patient Name', value: formatPatientName(p) },
    { label: 'MRN', value: p.id },
    { label: 'Date of Birth', value: p.birthDate || '—' },
    { label: 'Age', value: getPatientAge(p.birthDate) },
    { label: 'Sex', value: p.gender || '—' },
    { label: 'Phone', value: p.telecom?.find((t) => t.system === 'phone')?.value || '—' },
    { label: 'Address', value: formatAddress(p.address?.[0]) || '—' },
  ];

  function formatAddress(addr) {
    if (!addr) return null;
    return [addr.line?.join(', '), addr.city, addr.state, addr.postalCode].filter(Boolean).join(', ');
  }

  el.innerHTML = `
    <div class="demographics-grid">
      ${items.map((i) => `<div class="demographics-item"><div class="label">${i.label}</div><div class="value">${escapeHtml(String(i.value))}</div></div>`).join('')}
    </div>
  `;
}

async function generateAISummary(type) {
  const btn = type === 'discharge' ? elements.generateDischargeBtn : elements.generatePrevisitBtn;
  const content = type === 'discharge' ? elements.dischargeContent : elements.previsitContent;

  btn.disabled = true;
  content.textContent = 'Generating... (n8n workflow integration pending)';

  setTimeout(() => {
    content.textContent =
      type === 'discharge'
        ? '[Discharge Summary]\n\nIntegrate with n8n: webhook receives patientId, fetches FHIR data, calls LLM, returns summary.'
        : '[Pre-visit Summary]\n\nIntegrate with n8n: webhook receives patientId, fetches FHIR data, calls LLM, returns pre-visit summary.';
    btn.disabled = false;
  }, 800);
}

function showLoading(show) {
  elements.loadingOverlay?.classList.toggle('hidden', !show);
}
